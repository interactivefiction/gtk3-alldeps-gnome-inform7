## Osxcart was written by ##
- Philip Chimento - @ptomato

## Code contributed by ##
- @tsujan

Some test cases are used and distributed with the kind permission of:
- Sean M. Burke (http://interglacial.com/rtf)
- Jani Giannoudis (http://www.codeproject.com/KB/recipes/RtfConverter.aspx)
